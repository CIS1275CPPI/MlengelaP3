/************************************************************************************************
* Program: To implement a vector list to hold a collection of values of the same type.
* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
* Date: 20 September 2021.
* Purpose: Write a program in C++ to create three vectors.  
* The first vector, called first, will be a default vector with no elements.
* Add three values to first:   16, -55, 88.
* The second vector, called second will have room for 4 elements, but no values.
* The third vector will be initialized to have 5 elements: 13, 67, -8, 53, 22
* Then you will delete 2 elements from it. 
* Display the size of each vector when you are finished.
*************************************************************************************************/

#include <iostream>
#include <vector>

using namespace std;

int main()
{
	/* *********************************************************
	 *First, we need to construct vectors. Empty vector of ints.
	************************************************************/
	vector <int> first;
	/************************************************************
	* Second, add three ints to first. 
	*************************************************************/
	first.push_back(16);
	first.push_back(-55);
	first.push_back(55);
	/***********************************************************
	* Third, vector for four ints
	************************************************************/
	vector<int> second(4);

	/**********************************************************
	* Fourth, Vector initialization with 5 ints
	***********************************************************/
	vector<int> third{ 13, 67, -8, 53, 22 };

	/**********************************************************
	* Fifth, Remove tow elements from third. 
	**********************************************************/
	third.pop_back();
	third.pop_back();

	/************************************************************
	* Sixth, display the vector and their size.
	**************************************************************/
	cout << "\n\n The first vector has " << first.size() << "elements. ";
	cout << "\n They are: ";
	for (unsigned x = 0; x < first.size(); ++x)
	{
		cout << "\n Element " << x << " is " << second.at(x);
	}
	cout << "\n\n The second Vector has " << second.size() << " elements. ";
	cout << "\n They are: ";
	for (unsigned x = 0; x < second.size(); ++x)
	{
		cout << "\n\n The third vector has " << third.size() << "elements. ";
		cout << "\n They are: ";

		for (unsigned x = 0; x < third.size(); ++x)
		{
			cout << "\n Element " << x << " is " << third.at(x);
		}
		cout << "\n Good-bye! Aren't vectors fun! " << endl << endl;

	}

	return 0;

}