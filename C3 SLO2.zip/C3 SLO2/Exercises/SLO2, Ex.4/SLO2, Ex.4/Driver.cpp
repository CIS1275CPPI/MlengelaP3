/************************************************************************************************
* Program: To use nested loops structures for more complex conditions. 
* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
* Date: 20 September 2021.
* Purpose: Write a C++ program to create a Multiplication Table of ints from 12 to 15, 
* to be multiplied by numbers from 1 through 10.   So the rows will be 12, 13 14, 15.
* The columns will be 1 � 10.
*************************************************************************************************/

#include <iostream>
#include <string>

using namespace std;

int main()
{
	int i{ 0 };
	int j{ 0 };
	for (i = 12; i < 14; i++)   /* outer loop*/
	{
		cout << "Table of " << i << endl;
		for (j = 1; j <= 10; j++)  /* inner loop*/
		{
			cout << i << "*" << (i * j) << endl;
		}
		cout << endl;
	}

	return 0;

}